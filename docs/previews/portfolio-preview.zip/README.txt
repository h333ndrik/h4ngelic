h4ngelic – interaktive Vorschau

1. Diese ZIP-Datei entpacken.
2. h4ngelic-preview.html mit Chrome oder Firefox öffnen.

Alle Website-Dateien und das gelieferte grün-schwarze Original sind enthalten.
Es ist kein Server und keine Internetverbindung erforderlich.

Desktop: 4 mindestens eine Sekunde halten. Zurück: 3 dreimal kurz drücken.
Mobil: das kleine h4 viermal kurz antippen; zurück dreimal.
Unter More → Digital Artworks nach unten scrollen, um das Original zu enthüllen.

Die echte Mannequin-Datei fehlt noch; deshalb erscheint kein unkonfigurierter 3D-Schalter.
