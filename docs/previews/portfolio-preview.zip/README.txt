H4NGELIC — OFFLINE-VORSCHAU

Die Datei h4ngelic-preview.html in einem aktuellen Desktop-Browser (z. B. Chrome) öffnen. Alle benötigten Dateien sind eingebettet; Internet und Server sind nicht nötig.

Auf GitHub: HTML-Datei aufrufen, Download raw file wählen und die gespeicherte HTML-Datei öffnen.

Desktop: 4 mindestens eine Sekunde halten. Zurück: 3 dreimal drücken.
Mobil: auf das feste h4 viermal tippen; dreimal führt zurück.
Logo kurz anklicken oder antippen: Farbe auf der 3D-Oberfläche. Ziehen bewegt das Logo.

Die Vorschau wurde als exakte Datei mit vollständig blockierten HTTP-Anfragen geprüft.
